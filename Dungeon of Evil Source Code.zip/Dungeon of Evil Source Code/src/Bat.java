public class Bat extends Mob {
    public Bat() {
        super("BAT", "Bat", 25, new Ability[]{
                new DamageAbility("Swipe", 5, 0, 0),
                new Bite(),
                new HealthAbility("Darkness Rejuvenation", 3, 2, 0)
        }, new Item[]{
            new HealthPotion(25,1, 1d/2d)
        });
    }

    @Override
    public void battlecry() {
        super.say("Ah, so you stumble upon me and expect me to flutter away? Well think again! for I have been brooding with the evil cunning of the powers below; I call upon my power to wreck you to smithereens! Prepare now to face the full wrath of my claws and venom!");
    }

    @Override
    public Bat copy() {
        return new Bat();
    }
}
