//this is a test item
public class SwordOfAThousandSuns extends PermanentItem{
    public SwordOfAThousandSuns() {
        super(Format.YELLOW + "Sword of a Thousand Suns" + Format.RESET, 9999, 0, true, false, 0, 0);
    }

    @Override
    public void use(Entity e) {
        e.health -= super.effectStrength;
        super.fillCooldown();
        System.out.println("I STRIKE UPON THEE THE POWER OF A THOUSAND SUNS!!!");
    }
}
