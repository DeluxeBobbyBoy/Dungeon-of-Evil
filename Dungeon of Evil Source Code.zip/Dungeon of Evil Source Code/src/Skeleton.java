public class Skeleton extends Mob {
    public Skeleton() {
        super("SKT", "Skeleton", 75, new Ability[]{
                new DamageAbility("Swipe", 5, 0, 0),
                new DamageAbility("Lunge", 25, 5, 0)
        }, new Item[]{
                new HealthPotion(25,1, 1d/2d),
                new ManaPotion(25, 1, 1)
        });
    }

    @Override
    public void battlecry() {
        super.say("The evil that permeates this dungeon surges new life into my being. Attack, and I will not hesitate to protect that which brings me life--even if at my own semi-mortal expense. You have no proper business here, leave at once!");
    }

    @Override
    public Skeleton copy() {
        return new Skeleton();
    }
}
