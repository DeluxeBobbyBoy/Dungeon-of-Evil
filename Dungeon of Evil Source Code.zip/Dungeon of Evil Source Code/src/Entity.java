import java.sql.Array;
import java.util.ArrayList;

public class Entity {
    private BoardCell cell;
    private BoardCell onCell;
    public int health;
    public int maxHealth;
    public Ability[] abilities;
    private String name;
    private ArrayList<Modifier> modifiers;

    public Entity(String face, String name, int health, Ability[] abilities) {
        this.cell = new BoardCell(face);
        this.health = health;
        this.maxHealth = this.health;
        this.abilities = abilities;
        this.name = name;
        this.modifiers = new ArrayList<>();
    }

    public BoardCell getCell() {
        return cell;
    }

    public void setOnCell(BoardCell cell) {
        onCell = cell;
    }

    public BoardCell getOnCell() {
        return onCell;
    }

    public String getFace() {
        return cell.getTrueFace();
    }

    public String getName() {
        return name;
    }

    public void stepCooldowns() {
        for (int i = 0; i < abilities.length; i++) {
            abilities[i].stepCooldown();
        }
    }
    public boolean isAlreadyModifier(Modifier m) {
        for (Modifier modifier : modifiers) {
            if (modifier.getClass() == m.getClass()) {
                return true;
            }
        }
        return false;
    }

    public void addModifier(Modifier m) {
        if (isAlreadyModifier(m)) {

            for (Modifier modifier: modifiers) {

                if (modifier.getClass() == m.getClass()) {
                    modifier.fillDuration();
                    break;
                }

            }

        }
        else {
            modifiers.add(m);
        }
    }

    //make sure to override this method in player for extra unique modifiers (actually, don't. stop doing feature creep)
    public void stepModifiers() {
        ArrayList<Modifier> remove = new ArrayList<>();

        for (Modifier m: modifiers) {
            m.step();

            if (m.getDuration() > 0) {

                if (m instanceof Burn) {
                    health -= m.getEffectStrength() + maxHealth/100;
                }

                if (m instanceof Venom) {
                    health -= m.getEffectStrength();
                }

                if (m instanceof Fed) {
                    health += m.getEffectStrength();
                }

                if (m instanceof ShadowFreeze) {
                    health -= m.getEffectStrength() + maxHealth/50;
                }

            }
            else {
                remove.add(m);
            }

        }
        modifiers.removeAll(remove);
    }

    public String modifiersToString() {
        String s = "";

        for (Modifier m: modifiers) {
            s += m + " (" + m.getDuration() + ") ";
            if (m.count > 1) {
                s += " " + m.count + "x ";
            }
        }

        return s;
    }

    public void adjustStats() {
        if (health > maxHealth) {
            health = maxHealth;
        }
    }

    //steps everything steppable
    public void step() {
        stepModifiers();
        stepCooldowns();
        adjustStats();
    }

    public void say(String s) {
        System.out.println(name + ":");
        Format.printToLimit(  s);
    }

    @Override
    public String toString() {
        return name;
    }
}
