public class Goblin extends Mob {
    public Goblin() {
        super("GBN", "Goblin", 30, new Ability[]{
                new DamageAbility("Hit", 5, 0, 0),
        }, new Item[]{
                new HealthPotion(50,1, 1d/4d),
                new ManaPotion(50, 1, 1d/4d)
        });
    }

    @Override
    public void battlecry() {
        super.say("You challenge me, I see... I see... What is it you want, riches, status, power? And you think you can get it from me? Folly! Perhaps I may not be a formidable foe, but beware of the powers hidden below. I take no joy in victory from violence, but I will do what I must to stop others from seeing the horrors that lay onward.");
    }

    @Override
    public Goblin copy() {
        return new Goblin();
    }
}
