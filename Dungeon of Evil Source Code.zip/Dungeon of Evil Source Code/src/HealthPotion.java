public class HealthPotion extends NonPermanentItem {

    public HealthPotion(int effectStrength, int count, double dropChance) {
        super("Health Potion", effectStrength, count, dropChance, false, false);
    }

    @Override
    public void use(Entity e) {
        e.health += super.effectStrength;
    }
}
