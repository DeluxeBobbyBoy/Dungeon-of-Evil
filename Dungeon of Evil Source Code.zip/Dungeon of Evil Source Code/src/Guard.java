public class Guard extends Mob {
    public Guard() {
        super("GRD", "Guard", 100, new Ability[]{
                new DamageAbility("Spirit Slice", 25, 0, 0),
                new DamageAbility("Shadow Rush", 50, 3, 0),
                new HealthAbility("Super Darkness Rejuvenation", 25, 2, 0)
        }, new Item[]{
                new SwordOfProvidence(),
                new HealthPotion(25,1, 1d/2d)
        });
    }

    @Override
    public void battlecry() {
        super.say("Halt! I stand on guard for the Lord. Have you no heed for your encounters thus far? I pity your ignorance. You have passed beyond the point of warning; any further advice I grant you will certainly disregard. If you truly wish to pass through these gates, you must first prove your worth. Duel me and challenge the might of Providence!");
    }

    @Override
    public Guard copy() {
        return new Guard();
    }
}
