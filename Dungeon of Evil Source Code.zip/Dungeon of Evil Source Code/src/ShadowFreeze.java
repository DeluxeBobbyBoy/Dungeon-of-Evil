public class ShadowFreeze extends Modifier {
    public ShadowFreeze() {
        super(Format.PURPLE + "Shadow Freeze" + Format.RESET, 3, 15);
    }
}
