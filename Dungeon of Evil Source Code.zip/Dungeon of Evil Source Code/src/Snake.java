import java.awt.image.BufferedImage;

public class Snake extends Mob {
    public Snake() {
        super("SNK", "Snake", 150, new Ability[]{
                new DamageAbility("Tail Whip", 20, 0, 0),
                new Bite(),
                new DamageAbility("Constriction", 45, 7, 0)
        }, new Item[]{
                new HealthPotion(50,1, 1d/2d),
                new ManaPotion(50, 1, 1d/2d),
                new SnakeFang()
        });
    }

    @Override
    public void battlecry() {
        super.say("My friend, you have made a grave error trespassing into our dwelling. My bite is amplified with the power that emanates below. I feel sorry for you; you are woefully oblivious to the suffering you are about to receive. I will crush you like a rat!");
    }

    @Override
    public Snake copy() {
        return new Snake();
    }
}
