public class Bite extends DamageAbility {
    public Bite() {
        super("Bite", 15, 3, 0);
    }

    @Override
    public void use(Entity entity) {
        super.use(entity);

        Venom venom = new Venom();
        entity.addModifier(venom);
        System.out.println(this + " applied " + venom + "!");
    }
}
