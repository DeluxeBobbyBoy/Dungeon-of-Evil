public class MobCell extends BoardCell {
    private Mob mobType;

    public MobCell(Mob mobType) {
        super(mobType.getFace());
        this.mobType = mobType;
    }

    public void setCellType(BoardCell cell) {
        this.mobType.setOnCell(cell);
    }

    public Mob getMobType() {
        return mobType;
    }

}
