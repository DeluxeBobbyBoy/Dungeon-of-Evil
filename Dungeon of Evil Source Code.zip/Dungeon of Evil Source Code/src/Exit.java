public class Exit extends BoardCell{
    public Exit() {
        super("EXT");
        super.show();
    }
}
