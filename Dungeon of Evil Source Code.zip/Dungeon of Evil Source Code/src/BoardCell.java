public class BoardCell {
    private String face;
    private String trueFace;
    private boolean show;

    public BoardCell(String face) {
        this.face = "   ";
//        this.face = face;
        this.trueFace = face;
    }

    public void hide() {
        face = "   ";
    }

    public void show() {
        face = trueFace;
    }

    public String getTrueFace() {
        return trueFace;
    }

    @Override
    public String toString() {
        return this.face;
    }

    public BoardCell copy() {
        return new BoardCell(trueFace);
    }
}
