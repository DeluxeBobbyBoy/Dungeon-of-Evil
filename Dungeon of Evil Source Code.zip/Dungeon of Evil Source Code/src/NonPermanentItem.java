public class NonPermanentItem extends Item {
    public int count;

    public NonPermanentItem(String name, int effectStrength, int count, double dropChance, boolean isTurnItem, boolean isCombatItem) {
        super(name, effectStrength, dropChance, isTurnItem, isCombatItem);

        this.count = count;
    }

    public boolean equals(NonPermanentItem item) {
        return this.getClass() == item.getClass() && super.effectStrength == item.effectStrength;
    }
}
