public class Wall extends BoardCell{

    public Wall(String face) {
        super(face);
    }

    @Override
    public Wall copy() {
        return new Wall(super.getTrueFace());
    }

}
