public class ManaPotion extends NonPermanentItem{
    public ManaPotion(int effectStrength, int count, double dropChance) {
        super("Mana Potion", effectStrength, count, dropChance, false, false);
    }

    @Override
    public void use(Entity e) {
        if (e instanceof Player) {
            ((Player) e).mana += super.effectStrength;
        }
    }
}
