public class Mob extends Entity {
    private Item[] items;

    public Mob(String face, String name, int health, Ability[] abilities, Item[] droppableItems) {
        super(face, name, health, abilities);

        this.items = droppableItems;
    }

    public void show() {
        Format.printInLine(super.getName().toUpperCase());
        System.out.println();

        Format.center("Health: " + Format.RED + super.health + Format.RESET + "/" + Format.RED + super.maxHealth + Format.RESET + " " + modifiersToString());
        System.out.println();

        Format.line();
        System.out.println();
    }

    //override this method
    public void battlecry() {
        System.out.println("Override this method");
    }

    public Item[] drop() {
        return items;
    }

    public Item[] getItems() {
        return items;
    }

    public Mob copy() {
        return new Mob(super.getFace(), super.getName(), super.health, super.abilities, items);
    }

}
