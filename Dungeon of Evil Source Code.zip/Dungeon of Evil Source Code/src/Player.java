import java.util.Arrays;

public class Player extends Entity {
    public Item[] inventory;
    public int mana;
    public int maxMana;
    public int manaRegen;

    public Player(int health, int mana) {
        super("PLR", "Player", health, new Ability[]{
                new DamageAbility("Nothing", 0, 0, 0),
                new DamageAbility("Punch", 5, 0, 0),
                new HealthAbility("Heal", 20, 2, 15),
                new Fireball()
        });

        super.getCell().show();

        this.inventory = new Item[5];
        Arrays.fill(inventory, new EmptyItem());

        this.mana = mana;
        this.maxMana = this.mana;
        this.manaRegen = (maxMana/5);
    }

    public Ability nothing() {
        return super.abilities[0];
    }

    public Ability punch() {
        return super.abilities[1];
    }

    public Ability heal() {
        return super.abilities[2];
    }

    public Ability fireball() {
        return super.abilities[3];
    }

    public Ability useAbility(String input) {
        switch (input) {
            case "z":
                return nothing();
            case "x":
                return punch();
            case "c":
                return heal();
            case "v":
                return fireball();
        }
        return null;
    }

    public boolean isInventoryFull() {
        for (int i = 0; i < inventory.length; i++) {
            if (inventory[i] instanceof EmptyItem) {
                return false;
            }
        }
        return true;
    }

    public boolean hasInInventory(Item item) {
        for (int i = 0; i < inventory.length; i++) {
            if (inventory[i] instanceof  NonPermanentItem && item instanceof NonPermanentItem) {
                if (((NonPermanentItem) inventory[i]).equals((NonPermanentItem) item)) {
                    return true;
                }
            }
        }
        return false;
    }

    //assumes inventory is not full
    public void addItemToInventory(Item item) {
        for (int i = 0; i < inventory.length; i++) {
            if (inventory[i] instanceof NonPermanentItem && item instanceof NonPermanentItem) {
                if (((NonPermanentItem) inventory[i]).equals((NonPermanentItem) item)) {
                    ((NonPermanentItem) inventory[i]).count++;
                    break;
                }
            }
            if (inventory[i] instanceof EmptyItem) {
                inventory[i] = item;
                break;
            }
        }
    }

    public void stepInventory() {
        for (int i = 0; i <inventory.length; i++) {

            if (inventory[i] instanceof NonPermanentItem) {

                if (((NonPermanentItem) inventory[i]).count <= 0) {
                    inventory[i] = new EmptyItem();
                }

            }

        }
    }

    public void show() {
        Format.printInLine("PLAYER");
        System.out.println();

        Format.center("Health: " + Format.GREEN + super.health + Format.RESET + "/" + Format.GREEN + super.maxHealth + Format.RESET
                + " Mana: " + Format.BLUE + mana + Format.RESET + "/" + Format.BLUE + maxMana + Format.RESET
                + " " + super.modifiersToString());
        System.out.println();

        Format.line();
        System.out.println();
    }

    public void showAbilities() {
        Format.printInLine("ABILITIES");
        System.out.println();

        String abilityLine = "";

        abilityLine += "Z. " + abilities[0] + " " + printAbilityCooldown(abilities[0]) + " ";
        abilityLine += "X. " + abilities[1] + " " + printAbilityCooldown(abilities[1]) + " ";
        abilityLine += "C. " + abilities[2] + " " + printAbilityCooldown(abilities[2]) + " ";
        abilityLine += "V. " + abilities[3] + " " + printAbilityCooldown(abilities[3]) + " ";

        Format.printInLine(abilityLine, ' ');

        System.out.println();
        Format.line();
        System.out.println();
    }

    public void showInventory() {
        Format.printInLine("INVENTORY");
        System.out.println();

        String inventoryLine = "";

        for (int i = 0; i < inventory.length; i++) {
            inventoryLine += (i+1) + ". " + inventory[i] + " ";

            if (inventory[i] instanceof NonPermanentItem) {
                inventoryLine += "(" + ((NonPermanentItem) inventory[i]).count + ") ";
            }

            if (inventory[i] instanceof PermanentItem) {
                inventoryLine += printItemCooldown((PermanentItem) inventory[i]) + " ";
            }
        }

        Format.printInLine(inventoryLine, ' ');

        System.out.println();
        Format.line();
        System.out.println();
    }


    public void showAbilityAndItemTab() {
        showAbilities();
        showInventory();
    }

    private static String printAbilityCooldown(Ability a) {
        if (a.getCooldown() > 0) {
            return Format.YELLOW + "(-" + a.getCooldown() + ")" + Format.RESET;
        }
        if (a.getManaCost() > 0) {
            return Format.BLUE + "(" + a.getManaCost() + ")" + Format.RESET;
        }
        return Format.GREEN + "(Ready)" + Format.RESET;
    }

    private static String printItemCooldown(PermanentItem item) {
        if (item.getCooldown() > 0) {
            return Format.YELLOW + "(-" + item.getCooldown() + ")" + Format.RESET;
        }
        if (item.getManaCost() > 0) {
            return Format.BLUE + "(" + item.getManaCost() + ")" + Format.RESET;
        }
        return Format.GREEN + "(Ready)" + Format.RESET;
    }

    @Override
    public void stepCooldowns() {
        super.stepCooldowns();
        for (int i = 0; i < inventory.length; i++) {
            if (inventory[i] instanceof PermanentItem) {
                ((PermanentItem) inventory[i]).stepCooldown();
            }
        }
    }

    @Override
    public void adjustStats() {
        super.adjustStats();
        if (mana > maxMana) {
            mana = maxMana;
        }
    }

    public void stepMana() {
        mana = mana + manaRegen;
    }

    @Override
    public void step() {
        stepMana();
        super.step();
        this.adjustStats();
    }
}
