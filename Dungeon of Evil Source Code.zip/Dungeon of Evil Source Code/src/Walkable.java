public class Walkable extends BoardCell{

    public Walkable(String face) {
        super(face);
    }

    @Override
    public Walkable copy() {
        return new Walkable(super.getTrueFace());
    }

}
