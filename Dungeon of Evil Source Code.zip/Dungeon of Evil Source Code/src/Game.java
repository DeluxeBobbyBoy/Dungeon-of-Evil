import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.ArrayList;

public class Game {
    private static Board board = new Board(15);
    private static Player player = new Player(100, 100);
    private static int onLevel = 0;

    public static boolean hasWon = false;
    public static boolean inGame = true;

    private final static int STEP = 1;

    public static void reset() {
        board = new Board(15);
        player = new Player(100, 100);
        onLevel = 0;
        hasWon = false;
        inGame = true;
        board.clear();
    }

    public static void start() {
        //this is temporary
//        player.inventory[0] = new HealthPotion(25,2, 1);
//        player.addItemToInventory(new SwordOfProvidence());
//        player.addItemToInventory(new SnakeFang());
//        player.addItemToInventory(new SwordOfAThousandSuns());
//        player.addItemToInventory(new ShadowStaff());
        board.clear();

        String levelText = "";

        switch (onLevel) {
            case 0:
                levelText = "You enter the long abandoned dungeon site. The air around you is cold and still. No movement is discernible save for the occasional scuttle and screech of the bats. The only light comes from the occasional cracks in the ceiling. This is going to be a long journey...";
                board.generate(3, 2,  3,
                        new Mob[]{
                                new Bat(),
                                new Skeleton()
                        },
                        new Item[]{
                                new HealthPotion(25,1, 1),
                                new ManaPotion(25, 1, 1),
                                new Steak()
                });
                board.setCell(board.size()-1, board.size()-1, new Exit());
                break;
            case 1:
                levelText = "You descend deeper and deeper into the lower and more hidden depths of the dungeon. The decaying and mossy stone walls become gradually more intentional and fine-cut. You notice a subtle warmth now coming from the ground. The faint hissing of snakes is prominent in your ears as the pathway darkens. A single lit torch can be seen at the turn of the corridor. A sudden wave of fear floods your body--one that doesn't quite leave.";
                board.generate(10, 2,  4,
                        new Mob[]{
                                new Snake(),
                                new Goblin()
                        },
                        new Item[]{
                                new HealthPotion(50,1, 1),
                                new ManaPotion(50, 1, 1)
                });
                board.setCell(board.size()-1, board.size()-1, new Exit());
                player.maxHealth = 120;
                player.health += 20;
                break;
            case 2:
                levelText = "You find and make your way down a grand staircase of polished stone. The walls are etched red with writing in a language seemingly unknown to the world. The heat flowing in front of you is enough to make you sweat. Shadows cold as ice swirl and run like water at your feet. Your throat closes tight. You can feel your heartbeat and the rush of blood in every pulse. Despite that, you feel a powerful sense of invigoration and march into the callous stronghold unfazed.";
                board.generate(4, 1,  6,
                        new Mob[]{
                                new ShadowSpirit()
                        },
                        new Item[]{
                                new HealthPotion(100,1, 1),
                                new ManaPotion(100, 1, 1)
                });
                board.setCell(board.size()-2, board.size()-1, new MobCell(new Guard()));
                board.setCell(board.size()-1, board.size()-1, new Exit());
                player.maxHealth = 200;
                player.health += 80;
                break;
            case 3:
                Axiom axiom = new Axiom();
                hasWon = battle(axiom);
                inGame = false;
                break;
        }

        //place player
        player.setOnCell(board.getCell(0,0));
        board.setCell(0,0, player.getCell());

        Format.printToLimit(levelText);
        System.out.println();

        board.revealSurroundingCells(board.getCoordinatesOf(player.getCell())[0], board.getCoordinatesOf(player.getCell())[1]);

        if (onLevel == 0) {
            board.show();
            System.out.println("What will you do? (move [w/a/s/d] open inventory [i])");
        }

    }

    public static void loop() {
        int[] plrCoords = board.getCoordinatesOf(player.getCell());
        int plrX = plrCoords[0];
        int plrY = plrCoords[1];

        int moveQueueX = 0;
        int moveQueueY = 0;

        boolean moved = true;

        do {//i've never needed to use these before--curious!
            Scanner ui = new Scanner(System.in);
            String input = ui.nextLine();

            switch (input) {
                case "w":
                    moveQueueY = -STEP;
                    moved = true;
                    break;
                case "a":
                    moveQueueX = -STEP;
                    moved = true;
                    break;
                case "s":
                    moveQueueY = STEP;
                    moved = true;
                    break;
                case "d":
                    moveQueueX = STEP;
                    moved = true;
                    break;
                case "i":
                    player.show();
                    player.showAbilities();
                    player.showInventory();
                    Scanner ui2 = new Scanner(System.in);

                    System.out.println("Use item or ability [u] or leave [l]");
                    String choice = ui2.nextLine();

                    switch (choice) {
                        case "u":
                            useItemOrAbility(null);
                            break;
                        case "l":
                            break;
                    }

                    moved = false;
                    board.show();
                    System.out.println("What will you do? (move [w/a/s/d] open inventory [i])");

                    break;
            }

            if (plrX+moveQueueX > board.size()-1 || plrX+moveQueueX < 0 || plrY+moveQueueY > board.size()-1 || plrY+moveQueueY < 0) {
                moved = false;
                moveQueueY = 0;
                moveQueueX = 0;
            }

        } while (!moved);

        BoardCell cellCandidate = board.getCell(plrX+moveQueueX, plrY+moveQueueY);

        if (cellCandidate instanceof Walkable) {
            movePlayer(moveQueueX, moveQueueY);
        }
        else if (cellCandidate instanceof MobCell) {
            boolean won = battle(((MobCell) cellCandidate).getMobType());

            if (won) {
                int[] mobCoords = board.getCoordinatesOf(cellCandidate);
                int mobX = mobCoords[0];
                int mobY = mobCoords[1];

                board.setCell(mobX, mobY, new Walkable(" - "));

                movePlayer(moveQueueX, moveQueueY);
            }
        }
        else if (cellCandidate instanceof ItemCell) {
            pickUpItem(((ItemCell) cellCandidate).getItem());
            board.setCell(board.getCoordinatesOf(cellCandidate)[0], board.getCoordinatesOf(cellCandidate)[1], new Walkable(" - "));
            movePlayer(moveQueueX, moveQueueY);
        }
        else if (cellCandidate instanceof Exit) {
            onLevel++;
            start();
        }

        player.stepModifiers();
        player.stepCooldowns();

        if (player.health <= 0) {
            inGame = false;
        }

        if (inGame) {
            board.show();
            System.out.println("What will you do? (move [w/a/s/d] open inventory [i])");
        }
    }

    private static void movePlayer(int x, int y) {
        int[] plrCoords = board.getCoordinatesOf(player.getCell());
        int plrX = plrCoords[0];
        int plrY = plrCoords[1];

        board.setCell(plrX, plrY, player.getOnCell());
        player.setOnCell(board.getCell(plrX+x, plrY+y));
        board.setCell(plrX+x, plrY+y, player.getCell());

        board.revealSurroundingCells(plrX+x, plrY+y);

    }

    //returns true if won, false otherwise.
    private static boolean battle(Mob mob) {
        System.out.println("You encounter " + mob + "!");
        System.out.println();
        mob.battlecry();
        System.out.println();

        while (true) {
            //have you died?
            if (player.health <= 0) {
                return false;
            }

            //in case the mob is killed by means other than direct damage
            if (mob.health <= 0) {
                break;
            }

            //show some stuff
            System.out.println();
            mob.show();
            System.out.println();
            player.show();
            System.out.println();

            //player's turn

            boolean hasChosen = false;

            while (!hasChosen) {
                System.out.println(Format.CYAN + "How will you respond?" + Format.RESET);
                System.out.println("Attack [a] Leave [l]");

                Scanner ui = new Scanner(System.in);
                String input = ui.nextLine();

                switch (input) {
                    //attack
                    case "a":
                        useItemOrAbility(mob);
                        hasChosen = true;
                        break;
                    //leave
                    case "l":
                        if (mob instanceof Axiom) {
                            System.out.println(Format.RED + "You don't flinch.");
                            System.out.println();
                        }
                        else {
                            return false;
                        }
                }
            }


            //you win when mob health = 0. If so, break out of loop and do winning stuff.
            if (mob.health <= 0) {
                break;
            }

            //mob's turn

            //compile ability indexes of which are off cooldown
            ArrayList<Integer> validAbilitiesIndexes = new ArrayList<>();

            for (int i = 0; i < mob.abilities.length; i++) {
                if (mob.abilities[i].getCooldown() == 0) {
                    validAbilitiesIndexes.add(i);
                }
            }

            //pick one at random
            Ability usedAbility = mob.abilities[validAbilitiesIndexes.get((int)(Math.random()*validAbilitiesIndexes.size()))];

            Ability.executeAbility(usedAbility, mob, player);

            //update entities
            player.step();
            mob.step();

        }

        System.out.println();
        System.out.println("You defeated the " + mob + "!");

        //reward drops (if any)
        Item[] drops = mob.drop();

        for (int i = 0; i < drops.length; i++) {
            double roll = Math.random();

            if (roll <= drops[i].dropChance) {
                pickUpItem(drops[i]);
            }
        }

        player.step();

        return true;
    }

    public static void useItemOrAbility(Mob mob) {
        boolean optionPicked = false;

        while(!optionPicked) {
            Scanner ui = new Scanner(System.in);

            player.showAbilityAndItemTab();
            System.out.println();
            System.out.println("What will you choose?");

            String useItemOrAbility = ui.nextLine();
            System.out.println();

            try {
                //using item from inventory
                if (Integer.parseInt(useItemOrAbility)-1 >= 0 && Integer.parseInt(useItemOrAbility)-1 < player.inventory.length) {
                    Item usedItem = player.inventory[Integer.parseInt(useItemOrAbility)-1];
                    boolean isValidItem = false;
                    boolean usedInCombat = true;
//                    System.out.println(usedItem instanceof PermanentItem && ((PermanentItem) usedItem).isOnCooldown());

                    //if used outside of combat
                    if (mob == null) {

                        if (usedItem.isCombatItem) {
                            System.out.println(Format.RED + "Invalid item: you are not in combat!" + Format.RESET);
                        }
                        else if (usedItem instanceof PermanentItem && ((PermanentItem) usedItem).isOnCooldown()) {
                            System.out.println(Format.RED + "That item is on cooldown!" + Format.RESET);
                        }
                        else {
                            isValidItem = true;
                            usedInCombat = false;
                            optionPicked = true;
                        }

                    }
                    else if (usedItem instanceof PermanentItem && ((PermanentItem) usedItem).isOnCooldown()) {
                        System.out.println(Format.RED + "That item is on cooldown!" + Format.RESET);
                    }
                    else {
                        isValidItem = true;

                        if (usedItem.isTurnItem) {
                            optionPicked = true;
                        }
                    }

                    if (isValidItem) {
                        Item.executeItem(usedItem, player, mob);
                        player.stepInventory();
                        player.adjustStats();

                        if (!usedInCombat) {
                            player.show();
                        }
                    }

                }
            }
            //using ability
            catch (NumberFormatException _) {
                Ability usedAbility = player.useAbility(useItemOrAbility);
                boolean isValidAbility = false;
                boolean usedInCombat = true;

                if (usedAbility == null) {
                    System.out.println(Format.RED + "That is not a valid ability!" + Format.RESET);
                }
                else if (usedAbility.isOnCooldown()) {
                    System.out.println(Format.RED + "That ability is on cooldown!" + Format.RESET);
                }
                else if (usedAbility.getManaCost() > player.mana) {
                    System.out.println(Format.RED + "You don't have enough mana!" + Format.RESET);
                }
                //if used outside of combat
                else if (mob == null) {

                    if (usedAbility.isCombatAbility) {
                        System.out.println(Format.RED + "Invalid ability: you are not in combat!" + Format.RESET);
                    }
                    else {
                        isValidAbility = true;
                        usedInCombat = false;
                        optionPicked = true;
                    }

                }
                else {
                    isValidAbility = true;
                    optionPicked = true;
                }

                if (isValidAbility) {
                    Ability.executeAbility(usedAbility, player, mob);

                    if (!usedInCombat) {
                        player.show();
                    }
                }
            }
        }
    }

    public static void pickUpItem(Item item) {
        System.out.println("You found " + item + "!");

        if (player.isInventoryFull() && !player.hasInInventory(item)) {
            Scanner ui = new Scanner(System.in);

            System.out.println("Would you like to pick it up? [y/n]");
            String input = ui.nextLine();

            switch (input) {
                case "y":

                    while (true) {
                        Scanner ui2 = new Scanner(System.in);
                        player.showInventory();
                        System.out.println("Which item would you like to replace?");

                        try {
                            int input2 = ui2.nextInt();

                            if (input2 >= player.inventory.length || input2 < 0) {
                                throw new InputMismatchException();
                            }

                            player.inventory[input2-1] = item;
                            break;

                        } catch (InputMismatchException _) {
                            System.out.println(Format.RED + "That is not a valid inventory space!" + Format.RESET);
                        }

                    }
                    break;
                case "n":
                    break;

            }
        }
        else {
            player.addItemToInventory(item);
        }

    }
}
