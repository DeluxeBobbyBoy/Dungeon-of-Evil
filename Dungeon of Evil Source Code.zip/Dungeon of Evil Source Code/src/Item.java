/*
    TO CREATE AN ITEM:
        Make a subclass that extends either NonPermanentItem or PermanentItem; Item is a base class and should not be constructed directly.
        Put its use effect in the static method found in the Item class.
 */

public class Item {
    public double dropChance;
    public String name;
    public boolean isTurnItem;
    public boolean isCombatItem;
    public int effectStrength;

    public Item(String name, int effectStrength, double dropChance, boolean isTurnItem, boolean isCombatItem) {
        this.dropChance = dropChance;
        this.name = name;
        this.isTurnItem = isTurnItem;
        this.isCombatItem = isCombatItem;
        this.effectStrength = effectStrength;
    }

    public void use(Entity e) {
        System.out.println("Override this method");
    }

    @Override
    public String toString() {
        return "(" + Format.CYAN + effectStrength + Format.RESET + ") " + name;
    }

    //i might as well have used polymorphism at this point (the whole point of this was to avoid that)
    public static void executeItem(Item item, Entity user, Entity opp) {
        int pUserHealth = user.health;
        int pOppHealth = 0;

        if (opp != null) {
            pOppHealth = opp.health;
        }

        if (item instanceof NonPermanentItem) {
            ((NonPermanentItem) item).count--;
        }

        if (user instanceof Player && item instanceof PermanentItem) {
            if (((PermanentItem) item).getManaCost() > 0) {
                ((Player) user).mana -= ((PermanentItem) item).getManaCost() + ((Player) user).manaRegen;
            }
        }

        if (item instanceof HealthPotion) {
            ((HealthPotion) item).use(user);
            System.out.println(user + " used " + item + "! (" + Format.GREEN + (user.health-pUserHealth) + Format.RESET + ")");
            System.out.println();
        }

        if (item instanceof ManaPotion) {
            ((ManaPotion) item).use(user);
            System.out.println(user + " used " + item + "! (" + Format.BLUE + (user.health-pUserHealth) + Format.RESET + ")");
            System.out.println();
        }

        if (item instanceof Steak) {
            item.use(user);
            System.out.println(user + " used " + item + "! (" + Format.GREEN + (user.health-pUserHealth) + Format.RESET + ")");
            System.out.println();
        }

        if (item instanceof SwordOfProvidence) {
            ((SwordOfProvidence) item).use(opp);
            System.out.println(user + " used " + item + "! (" + Format.RED + (pOppHealth-opp.health) + Format.RESET + ")");
            System.out.println();
        }

        if (item instanceof SnakeFang) {
            ((SnakeFang) item).use(opp);
            System.out.println(user + " used " + item + "! (" + Format.RED + (pOppHealth-opp.health) + Format.RESET + ")");
            System.out.println();
        }

        if (item instanceof ShadowStaff) {
            item.use(opp);
            System.out.println(user + " used " + item + "! (" + Format.RED + (pOppHealth-opp.health) + Format.RESET + ")");
            System.out.println();
        }

        if (item instanceof SwordOfAThousandSuns) {
            item.use(opp);
            System.out.println(user + " used " + item + "! (" + Format.RED + (pOppHealth-opp.health) + Format.RESET + ")");
            System.out.println();
        }
    }
}
