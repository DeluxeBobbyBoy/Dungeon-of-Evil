public class Fed extends Modifier {
    public Fed() {
        super(Format.GREEN + "Fed" + Format.RESET, 8, 5);
    }
}
