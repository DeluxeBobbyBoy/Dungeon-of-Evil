public class Axiom extends Mob {
    public Axiom() {
        super("AXM", "Axiom: Bearer of the Draconian Scourge", 1000, new Ability[]{
                new DamageAbility("Evil Storm", 35, 0, 0),
                new ShadowDash(),
                new DraconianFire(),
                new HealthAbility("Super Darkness Rejuvenation", 100, 5, 0)
        }, new Item[]{});
    }

    @Override
    public void battlecry() {
        super.say("I am the Keeper of the Dungeon, Bearer of the Eternal Draconian Scourge, and the Lord that oversees its captivity. You've been leeching mana from the inhabitants of the dungeon in combat to use as your own. Very clever. But I'm afraid that that was a grave miscalculation. By doing so, you've let your body become gradually and irreversibly infected with my strength. You are no less mortal now than I. I protect the world from a great evil that once plagued it, but at an equal cost. I am burdened with eternal life bound by torment. If I am slain, the hand that slayed me will inherit the evil that I posses, and all that it entails. You have been corrupted past all reason, and that corruption has led you to want to kill me; therefore, I must destroy you to prevent the curse from enslaving another soul.");
    }

    @Override
    public Axiom copy() {
        return new Axiom();
    }
}
