public class ShadowDash extends DamageAbility {
    public ShadowDash() {
        super("ShadowFreeze", 50, 3, 0);
    }

    @Override
    public void use(Entity entity) {
        super.use(entity);

        ShadowFreeze shadowFreeze = new ShadowFreeze();
        entity.addModifier(shadowFreeze);
        System.out.println(this + " applied " + shadowFreeze + "!");
    }
}
