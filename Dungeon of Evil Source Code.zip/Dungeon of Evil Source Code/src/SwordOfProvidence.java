public class SwordOfProvidence extends PermanentItem {
    private int dmg;
    public SwordOfProvidence() {
        super("Sword of Providence", 200, 1, true, true, 5, 0);
    }

    @Override
    public void use(Entity e) {
        e.health -= super.effectStrength;
        super.fillCooldown();
    }
}
