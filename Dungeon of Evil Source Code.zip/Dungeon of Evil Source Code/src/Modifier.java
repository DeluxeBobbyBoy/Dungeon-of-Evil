/*
    TO ADD A MODIFIER:
        Create a new class that extends modifier; fill in superclass constructor.
        Go to Entity class and go to stepModifier method. Create a new instanceof check, and put effect there.

        If used in an item or ability, override 'use' method and apply modifier there.
 */

public class Modifier {
    private String name;
    public int count;
    private int durationInterval;
    private int duration;
    private int effectStrength;

    public Modifier(String name, int durationInterval, int effectStrength) {
        this.name = name;
        this.count = 1;
        this.durationInterval = durationInterval;
        this.duration = this.durationInterval + 1;
        this.effectStrength = effectStrength;
    }

    public void add() {
        count++;
        duration += durationInterval;
    }

    public void clear() {
        count = 0;
        duration = 0;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public void fillDuration() {
        this.duration = durationInterval+1;
    }

    public int getEffectStrength() {
        return effectStrength;
    }

    public void step() {
        duration--;
    }

    @Override
    public String toString() {
        return name;
    }
}
