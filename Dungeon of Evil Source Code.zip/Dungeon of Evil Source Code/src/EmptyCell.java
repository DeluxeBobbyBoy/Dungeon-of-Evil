public class EmptyCell extends BoardCell {
    public EmptyCell() {
        super("   ");
    }
}
