public class SnakeFang extends PermanentItem {
    public SnakeFang() {
        super("Snake Fang", 50, 1d/4d, true, true, 1, 40);
    }

    @Override
    public void use(Entity e) {
        e.health -= super.effectStrength;

        Venom venom = new Venom();
        e.addModifier(venom);
        System.out.println(this + " applied " + venom + "!");

        super.fillCooldown();
    }
}
