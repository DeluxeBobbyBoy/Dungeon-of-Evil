public class Fireball extends DamageAbility {

    public Fireball() {
        super("Fireball", 10, 5, 30);
    }
    @Override
    public void use(Entity entity) {
        super.use(entity);

        Burn burn = new Burn();
        entity.addModifier(burn);
        System.out.println(this + " applied " + burn + "!");
    }
}
