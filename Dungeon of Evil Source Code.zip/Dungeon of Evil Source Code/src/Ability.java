/*
    TO CREATE AN ABILITY:
        First, do not create an ability directly via Ability class.
        Select either DamageAbility or HealthAbility. You can create an ability directly with these if you so please.

        If you want the effect to be something more specific (i.e. have modifiers),
 */

public class Ability {
    private String name;
    private int cooldown;
    private int maxCooldown;
    private int manaCost;
    public boolean isCombatAbility;

    public Ability(String name, int cooldown, int manaCost, boolean isCombatAbility) {
        this.name = name;
        this.cooldown = 0;
        this.maxCooldown = cooldown;
        this.manaCost = manaCost;
        this.isCombatAbility = isCombatAbility;
    }

    public int getMaxCooldown() {
        return maxCooldown;
    }

    public int getCooldown() {
        return cooldown;
    }

    public void setCooldown(int cooldown) {
        this.cooldown = cooldown;
    }

    public void stepCooldown() {
        if (cooldown > 0) {
            cooldown -= 1;
        }
    }

    public void fillCooldown() {
        cooldown = maxCooldown+1;
    }

    public void resetCooldown() {
        cooldown = 0;
    }

    public boolean isOnCooldown() {
        return cooldown > 0;
    }

    public int getManaCost() {
        return manaCost;
    }

    //a = ability to be used
    //user = entity using ability
    //opp = opponent
    //i might as well have used polymorphism at this point (the whole point of this was to avoid that)
    public static void executeAbility(Ability a, Entity user, Entity opp) {
        int pUserHealth = user.health;
        int pOppHealth = 0;

        if (opp != null) {
            pOppHealth = opp.health;
        }

        if (user instanceof Player) {
            if (a.manaCost > 0) {
                ((Player) user).mana -= a.manaCost + ((Player) user).manaRegen;
            }
        }

        if (a instanceof DamageAbility) {
            ((DamageAbility) a).use(opp);
            System.out.println(user + " used " + a + "! (" + Format.RED + (pOppHealth-opp.health) + Format.RESET + ")");
        }
        else if (a instanceof HealthAbility) {
            ((HealthAbility) a).use(user);
            System.out.println(user + " used " + a + "! (" + Format.GREEN + (user.health-pUserHealth) + Format.RESET + ")");
        }

        a.fillCooldown();

//        System.out.println(user + " used " + a + "! (");
    }

    @Override
    public String toString() {
        return name;
    }
}
