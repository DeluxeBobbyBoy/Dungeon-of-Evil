public class Burn extends Modifier {
    public Burn() {
        super(Format.YELLOW + "Burn" + Format.RESET, 3, 5);
    }
}
