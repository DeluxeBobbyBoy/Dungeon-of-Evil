import java.lang.reflect.Array;
import java.util.ArrayList;

public class Board {
    private BoardCell[][] grid;

    public Board(int size) {
        this.grid = new BoardCell[size][size];

        for (int h = 0; h < grid.length; h++) {
            for (int w = 0; w < grid[0].length; w++) {
                grid[h][w] = new Walkable(" - ");
            }
        }

    }

    public void show() {
        System.out.print(" ");

        Format.line('-', grid.length*3);

        System.out.println();

        for (int y = 0; y < grid.length; y++) {
            for (int x = 0; x < grid[0].length; x++) {

                if (x == 0) {
                    System.out.print("|");
                }

                System.out.print(grid[y][x]);

                if (x == grid[0].length-1) {
                    System.out.print("|");
                }

            }
            System.out.println();
        }

        System.out.print(" ");

        Format.line('-', grid.length*3);

        System.out.println();

    }

    public BoardCell getCell(int x, int y) {
        if (y > grid.length || y < 0) {
            return null;
        }
        if (x > grid[0].length || x < 0) {
            return null;
        }

        return grid[y][x];
    }

    public void setCell(int x, int y, BoardCell cell) {
        boolean validPosition = true;

        if (y > grid.length || y < 0) {
            validPosition = false;
        }
        if (x > grid[0].length || x < 0) {
            validPosition = false;
        }

        if (validPosition) {
            grid[y][x] = cell;
        }
    }

    public int[] getCoordinatesOf(BoardCell cell) {
        for (int y = 0; y < grid.length; y++) {
            for (int x = 0; x < grid[0].length; x++) {
                if (grid[y][x] == cell) {
                    return new int[]{x, y};
                }
            }
        }
        return null;
    }

    public void generate(int maxRooms, int minSize, int maxSize, Mob[] mobTypes, Item[] groundItems) {
        Walkable defaultWalkable = new Walkable(" - ");
        //make rooms and paths
        for (int i = 0; i < maxRooms; i++ ) {
            randomRectWithPath(1, grid[0].length, 1, grid.length, minSize, maxSize, minSize, maxSize, defaultWalkable);
        }

        //start
        ArrayList<int[]> candidates = isolateCellPositionsOfTypeWithExclusions(defaultWalkable, new ArrayList<>());
        int[] randomCandidate = candidates.get((int)(Math.random()*candidates.size()));

        path(0,0, randomCandidate[0], randomCandidate[1], defaultWalkable);

        //end
        candidates = isolateCellPositionsOfTypeWithExclusions(defaultWalkable, new ArrayList<>());
        randomCandidate = candidates.get((int)(Math.random()*candidates.size()));

        path(grid[0].length-1,grid.length-1, randomCandidate[0], randomCandidate[1], defaultWalkable);

        wrapWalkablesWithWalls(new Wall(" e "));

        placeMobs(mobTypes);
        placeItems(groundItems);

    }

    //generate a rectangle with bottom right corner position of x and y.
    private void generateRect(int posX, int posY, int sizeX, int sizeY, BoardCell cell) {
        for (int y = 0; y < grid.length; y++) {
            for (int x = 0; x < grid[0].length; x++) {
                if (x >= posX-sizeX && y >= posY-sizeY && x < posX && y < posY) {
                    grid[y][x] = cell.copy();
                }
            }
        }
    }

    private void placeRandomRect(int minX, int maxX, int minY, int maxY, int sizeX, int sizeY, BoardCell cell) {
        int posX = (int)(Math.random()*(maxX-sizeX+1)) + minX + sizeX - 1;
        int posY = (int)(Math.random()*(maxY-sizeY+1)) + minY + sizeY - 1;

//        System.out.println("PosX: " + posX + " PosY: " + posY);

        generateRect(posX, posY, sizeX, sizeY, cell);
        this.setCell(posX-1, posY-1, new Walkable(Format.RED + " S " + Format.RESET));
    }

    private void randomRectWithPath(int minX, int maxX, int minY, int maxY, int minSizeX, int maxSizeX, int minSizeY, int maxSizeY, BoardCell cell) {
        int sizeX = (int)(Math.random()*maxSizeX) + minSizeX;
        int sizeY = (int)(Math.random()*maxSizeY) + minSizeY;

//        System.out.println("SizeX: " + sizeX + " SizeY: " + sizeY);

        ArrayList<int[]> candidates = filterRectangleCandidatesWithBuffer(sizeX, sizeY, 1, scanForRectangleCandidates(sizeX, sizeY));

        if (!candidates.isEmpty()) {
            int[] pos = candidates.get((int) (Math.random() * candidates.size()));


            generateRect(pos[0], pos[1], sizeX, sizeY, cell);
            //temporary
//            this.setCell(pos[0] - 1, pos[1] - 1, new Walkable(Format.RED + " S " + Format.RESET));
//            this.setCell(pos[0]-sizeX, pos[1]-sizeY, new Walkable(Format.GREEN + " E " + Format.RESET));

            ArrayList<int[]> positions = isolateCellPositionsInRect(pos[0], pos[1], sizeX, sizeY);
            int[] randomCellPosition =  positions.get((int)(Math.random()*positions.size()));

            ArrayList<int[]> possiblePositions = isolateCellPositionsOfTypeWithExclusions(cell, positions);

            if (!possiblePositions.isEmpty()) {
                int[] randomPossiblePosition = possiblePositions.get((int) (Math.random() * possiblePositions.size()));

                path(randomCellPosition[0], randomCellPosition[1], randomPossiblePosition[0], randomPossiblePosition[1], cell);
            }
        }
//        placeRandomRect(minX, maxX, minY, maxY, sizeX, sizeY, cell);
    }

    private ArrayList<int[]> scanForRectangleCandidates(int sizeX, int sizeY) {
        ArrayList<int[]> rectCandidates = new ArrayList<>();

        for (int y = sizeY; y < grid.length; y++) {
            for (int x = sizeX; x < grid[0].length; x++) {
                if (isRectangleCandidate(x, y, sizeX, sizeY)) {
                    rectCandidates.add(new int[]{x,y});
                }
            }
        }

        return rectCandidates;
    }

    private ArrayList<int[]> filterRectangleCandidatesWithBuffer(int sizeX, int sizeY, int buffer, ArrayList<int[]> candidates) {
        ArrayList<int[]> updatedCandidates = new ArrayList<>();

        for (int[] candidate : candidates) {
            boolean isValidCandidate = true;

            for (int y = candidate[1] + buffer; y > candidate[1] - sizeY - 2*buffer; y--) {
                for (int x = candidate[0] + buffer; x > candidate[0] - sizeX - 2*buffer; x--) {
                    if (!( !(isWithinBounds(x, y)) || grid[y][x] instanceof EmptyCell)) {
                        isValidCandidate = false;
                        break;
                    }
                }
            }

            if (isValidCandidate) {
                updatedCandidates.add(candidate);
            }

        }

        return updatedCandidates;
    }

    private boolean isWithinBounds(int x, int y) {
        return x > 0 && x < grid[0].length && y > 0 && y < grid.length;
    }

    private boolean isRectangleCandidate(int posX, int posY, int sizeX, int sizeY) {
        for (int y = posY; y > posY-sizeY-1; y--) {
            for (int x = posX; x > posX-sizeX-1; x--) {
                if (!(grid[y][x] instanceof EmptyCell)) {
                    return false;
                }
            }
        }

        return true;
    }

    private void path(int x1, int y1, int x2, int y2, BoardCell cell) {
        //this code was partially generated by chatgpt (i spent so, so many hours trying to get this right on my own)
        if (x1 <= x2) {
            for (int x = x1; x <= x2; x++) {
                grid[y1][x] = cell.copy();
            }
        } else {
            for (int x = x1; x >= x2; x--) {
                grid[y1][x] = cell.copy();
            }
        }

        if (y1 <= y2) {
            for (int y = y1; y <= y2; y++) {
                grid[y][x2] = cell.copy();
            }
        } else {
            for (int y = y1; y >= y2; y--) {
                grid[y][x2] = cell.copy();
            }
        }
    }

    private ArrayList<int[]> isolateCellPositionsInRect(int posX, int posY, int sizeX, int sizeY) {
        ArrayList<int[]> positions = new ArrayList<>();

        for (int y = posY; y > posY-sizeY-1; y--) {
            for (int x = posX; x > posX-sizeX-1; x--) {
                positions.add(new int[]{x, y});
            }
        }

        return positions;
    }

    private ArrayList<int[]> isolateCellPositionsOfTypeWithExclusions(BoardCell type, ArrayList<int[]> exclusions) {
        ArrayList<int[]> cellPositions = new ArrayList<>();

        for (int y = 0; y < grid.length; y++) {
            for (int x = 0; x < grid[0].length; x++) {

                int[] pos = new int[]{x, y};
                if (grid[y][x].getClass().equals(type.getClass()) && !isItemInArrayList(pos, exclusions)) {
                    cellPositions.add(pos);
                }

            }
        }

        return cellPositions;
    }

    private boolean areArraysIdentical(int[] p1, int[] p2) {
        for (int i = 0; i < p1.length; i++) {
            if (p1[i] != p2[i]) {
                return false;
            }
        }
        return true;
    }

    private boolean isItemInArrayList(int[] p, ArrayList<int[]> positions) {
        for (int i = 0; i < positions.size(); i++) {
            if (areArraysIdentical(p, positions.get(i))) {
                return true;
            }
        }
        return false;
    }

    //holy alliteration...
//    private void wrapWalkablesWithWalls(Wall wall) {
//        for (int y = 0; y < grid.length; y++) {
//            for (int x = 0; x < grid[0].length; x++) {
//                if ((((x != grid[0].length-1 && grid[y][x+1] instanceof Walkable)
//                        || (x != 0 && grid[y][x-1] instanceof Walkable)) ||
//                        ((y != grid.length-1 && grid[y+1][x] instanceof Walkable) || (y != 0 && grid[y-1][x] instanceof Walkable))) && grid[y][x] instanceof EmptyCell) {
//                    grid[y][x] = wall.copy();
//                }
//            }
//        }
//    }

    private void wrapWalkablesWithWalls(Wall wall) {
        for (int y = 0; y < grid.length; y++) {
            for (int x = 0; x < grid[0].length; x++) {
                for (int y2 = 0; y2 < grid.length; y2++) {
                    for (int x2 = 0; x2 < grid[0].length; x2++) {
                        if (distance(x, y, x2, y2) < 2 && grid[y2][x2] instanceof EmptyCell && grid[y][x] instanceof Walkable) {
                            grid[y2][x2] = wall.copy();
                        }
                    }
                }
            }
        }
    }

    private void placeMobs(Mob[] mobTypes) {
        for (int y = 0; y < grid.length; y++) {
            for (int x = 0; x < grid[0].length; x++) {

                double roll = Math.random();
                //chance is such that enemies are more likely towards bottom right corner
                double chance = ((1d/8)*x)/(2*grid[0].length - x) + ((1d/8)*y)/(2*grid.length - y);

                if (roll < chance && grid[y][x] instanceof Walkable) {
                    grid[y][x] = new MobCell(pickRandomMob(mobTypes));
                }

            }
        }
    }

    private void placeItems(Item[] items) {
        for (int y = 0; y < grid.length; y++) {
            for (int x = 0; x < grid[0].length; x++) {

                double roll = Math.random();
                //chance is such that items are more likely towards bottom right corner
                double chance = ((1d/8)*x)/(2*grid[0].length - x) + ((1d/8)*y)/(2*grid.length - y);

                if (roll < chance && grid[y][x] instanceof Walkable) {
                    grid[y][x] = new ItemCell(pickRandomItem(items));
                }

            }
        }
    }

    private Mob pickRandomMob(Mob[] mob) {
        return mob[(int)(Math.random()*mob.length)].copy();
    }

    private Item pickRandomItem(Item[] items) {
        return items[(int)(Math.random()*items.length)];
    }

    public void revealSurroundingCells(int posX, int posY) {
        for (int y = 0; y < grid.length; y++) {
            for (int x = 0; x < grid[0].length; x++) {
                if (distance(posX, posY, x, y) < 2) {
                    grid[y][x].show();
                }
            }
        }
    }

    public double distance(int x1, int y1, int x2, int y2) {
        return Math.sqrt(Math.pow(x1-x2, 2) + Math.pow(y1-y2, 2));
    }

    public void clear() {
        for (int y = 0; y < grid.length; y++) {
            for (int x = 0; x < grid[0].length; x++) {
                grid[y][x] = new EmptyCell();
            }
        }
    }

    public int size() {
        return grid.length;
    }
}
