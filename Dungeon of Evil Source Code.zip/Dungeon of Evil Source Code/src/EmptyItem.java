public class EmptyItem extends Item {
    public EmptyItem() {
        super("---", 0, 1, false, false);
    }

    @Override
    public String toString() {
        return super.name;
    }
}
