public class Steak extends NonPermanentItem {
    public Steak() {
        super("Steak", 20, 1, 1, false, false);
    }

    public void use(Entity e) {
        Fed fed = new Fed();
        e.addModifier(fed);
        System.out.println(this + " applied " + fed + "!");
    }
}
