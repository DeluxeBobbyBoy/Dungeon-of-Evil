public class HealthAbility extends Ability {
    public int hlth;

    public HealthAbility(String name, int hlth, int cooldown, int manaCost) {
        super(name, cooldown, manaCost, false);

        this.hlth = hlth;
    }

    public void use(Entity e) {
        e.health += hlth + e.maxHealth/20;
        super.fillCooldown();
    }
}
