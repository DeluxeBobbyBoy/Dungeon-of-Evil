public class PermanentItem extends Item {
    private int cooldown;
    private int maxCooldown;
    private int manaCost;

    public PermanentItem(String name, int effectStrength, double dropChance, boolean isTurnItem, boolean isCombatItem, int cooldown, int manaCost) {
        super(name, effectStrength, dropChance, isTurnItem, isCombatItem);
        this.cooldown = 0;
        this.maxCooldown = cooldown;
        this.manaCost = manaCost;
    }

    public int getMaxCooldown() {
        return maxCooldown;
    }

    public int getCooldown() {
        return cooldown;
    }

    public void setCooldown(int cooldown) {
        this.cooldown = cooldown;
    }

    public void stepCooldown() {
        if (cooldown > 0) {
            cooldown -= 1;
        }
    }

    public void fillCooldown() {
        cooldown = maxCooldown+1;
    }

    public void resetCooldown() {
        cooldown = 0;
    }

    public boolean isOnCooldown() {
        return cooldown > 0;
    }

    public int getManaCost() {
        return manaCost;
    }
}
