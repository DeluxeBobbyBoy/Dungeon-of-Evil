public class ShadowSpirit extends Mob {
    public ShadowSpirit() {
        super("SHW", "Shadow Spirit", 250, new Ability[]{
                new DamageAbility("Spirit Slice", 25, 0, 0),
                new ShadowDash(),
                new HealthAbility("Super Darkness Rejuvenation", 50, 2, 0)
        }, new Item[]{
                new HealthPotion(100,1, 1d/2d),
                new ManaPotion(100, 1, 1d/2d),
                new ShadowStaff()
        });
    }

    @Override
    public void battlecry() {
        super.say("I draw from the ground form and power distilled to purity! Stay back! I will not willing allow another soul be rendered subject to the torture--too many have fallen with your pursuit. Leave with your remaining freedom!");
    }

    @Override
    public ShadowSpirit copy() {
        return new ShadowSpirit();
    }
}
