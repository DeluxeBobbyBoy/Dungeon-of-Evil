public class ShadowStaff extends PermanentItem {
    public ShadowStaff() {
        super("Shadow Staff", 75, 1d/6d, true, true, 5, 75);
    }

    public void use(Entity e) {
        e.health -= super.effectStrength;

        ShadowFreeze shadowFreeze = new ShadowFreeze();
        e.addModifier(shadowFreeze);
        System.out.println(this + " applied " + shadowFreeze + "!");

        super.fillCooldown();
    }
}
