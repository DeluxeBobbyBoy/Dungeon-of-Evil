public class DamageAbility extends Ability{
    public int dmg;

    public DamageAbility(String name, int dmg, int cooldown, int manaCost) {
        super(name, cooldown, manaCost, true);

        this.dmg = dmg;
    }

    public void use(Entity e) {
        e.health -= dmg;
        super.fillCooldown();
    }
}
