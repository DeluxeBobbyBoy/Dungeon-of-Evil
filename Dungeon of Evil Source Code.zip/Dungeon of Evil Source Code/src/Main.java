import java.text.Normalizer;
import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        boolean wantsToPlay = true;

        while (true) {
            //this is the menu
            boolean gameStart = false;
//        for (int i = 0; i < 200; i++) {
//            Game.start();
//            System.out.println();
//        }

            while (!gameStart && wantsToPlay) {
                Scanner ui = new Scanner(System.in);

                System.out.println("Welcome to Dungeons of Evil!");
                System.out.println("Start? [y/n]");
                String response = ui.nextLine().toLowerCase();

                switch (response) {
                    case "y":
                        gameStart = true;
                        Game.start();
                        break;
                    case "n":
                        gameStart = false;
                        wantsToPlay = false;
                        break;
                    default:
                        System.out.println(Format.RED + "Invalid answer!" + Format.RESET);
                        break;
                }

            }

            if (!wantsToPlay) {
                break;
            }

            while (Game.inGame) {
                Game.loop();
            }

            if (Game.hasWon) {
                Format.printToLimit("Your blood begins to sear as if infused with burning acid and glass shards. It knocks you to the ground in an instant. Your senses heighten tenfold, and you are racked with agony at the touch of the cold. You are immortal. Eternally enriched by the power of the Scourge, The doors of fate have been sealed, never to be reopened.");
                System.out.println();
                System.out.println();
                System.out.println("You win.");
                System.out.println();
            }
            else {
                System.out.println("You lose.");
                System.out.println();
            }

            Game.reset();
        }

    }
}