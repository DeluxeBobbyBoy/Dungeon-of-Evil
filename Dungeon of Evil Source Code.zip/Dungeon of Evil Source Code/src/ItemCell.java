public class ItemCell extends BoardCell {
    private Item item;

    public ItemCell(Item item) {
        super(" I ");

        this.item = item;
    }

    public Item getItem() {
        return item;
    }
}
