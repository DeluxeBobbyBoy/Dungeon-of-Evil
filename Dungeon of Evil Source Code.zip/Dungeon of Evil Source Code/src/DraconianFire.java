public class DraconianFire extends DamageAbility {
    public DraconianFire() {
        super("Draconian Fire", 25, 3, 0);
    }

    public void use(Entity e) {
        super.use(e);

        Burn burn = new Burn();
        e.addModifier(burn);
        System.out.println(this + " applied " + burn + "!");
    }
}
