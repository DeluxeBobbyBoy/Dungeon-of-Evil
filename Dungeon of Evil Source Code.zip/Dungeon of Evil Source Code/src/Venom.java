public class Venom extends Modifier{
    public Venom() {
        super(Format.GREEN + "Venom" + Format.RESET, 3, 5);
    }
}
