public class Format {
    public static final int DEFAULT_LINE_LENGTH = 75;
    public static final char DEFAULT_LINE_CHAR = '=';

    public static final String PURPLE = "\u001B[035m";
    public static final String RED = "\u001B[31m";
    public static final String BLUE = "\u001B[34m";
    public static final String YELLOW = "\u001B[33m";
    public static final String GREEN = "\u001B[32m";
    public static final String CYAN = "\u001B[36m";
    public static final String RESET = "\u001B[0m";

    public static void main(String[] args) {
        System.out.print(RED);
        printInLine(YELLOW + "MORBILLION" + RED);
        System.out.println(RESET);
        printInLine("MOBS");
        System.out.println();
        printInLine("test", '+', 20);
        System.out.println();
        center("SOME TEXT");
        System.out.println();
        line();
    }

    public static void line(char c, int length) {
        for (int i = 0; i < length; i++) {
            System.out.print(c);
        }
    }

    public static void line(char c) {
        line(c, DEFAULT_LINE_LENGTH);
    }

    public static void line(int length) {
        line(DEFAULT_LINE_CHAR, length);
    }

    public static void line() {
        line(DEFAULT_LINE_LENGTH);
    }

    public static void printInLine(String s, char c, int length) {
        //I got chatgpt to generate me this regex (I don't know how it works)
        int splitLength = length-s.replaceAll("\u001B\\[[;\\d]*m", "").length();

        if (splitLength % 2 == 1) {
            line(c,(splitLength/2)+1);
        }
        else {
            line(c,splitLength/2);
        }
        System.out.print(s);
        line(c, splitLength/2);
    }

    public static void printInLine(String s, int length) {
        printInLine(s, DEFAULT_LINE_CHAR, length);
    }

    public static void printInLine(String s, char c) {
        printInLine(s, c, DEFAULT_LINE_LENGTH);
    }

    public static void printInLine(String s) {
        printInLine(s, DEFAULT_LINE_CHAR, DEFAULT_LINE_LENGTH);
    }

    public static void center(String s) {
        printInLine(s, ' ');
    }

    public static void printToLimit(String s) {
        String[] split = s.split(" ");

        int lineLength = 0;
        for (int i = 0; i < split.length; i++) {
            lineLength += split[i].length()+1;

            System.out.print(split[i] + " ");

            if (lineLength >= DEFAULT_LINE_LENGTH-1) {
                System.out.println();
                lineLength = 0;
            }

        }
    }
}
